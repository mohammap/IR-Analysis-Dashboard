import dash
from dash import Dash, dcc, html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc
import os
import pandas as pd
import base64

import shutil
import sys
import time
import logging
from shutil import copyfile

import scipy
from watchdog.observers import Observer
from watchdog.events import LoggingEventHandler
from matplotlib import pyplot as plt
import math
import os
import sys
from matplotlib import pyplot as plt
from scipy.stats import skew, kurtosis
import numpy as np
import pandas as pd
import time
import os.path
from matplotlib.lines import Line2D
from shutil import copyfile
import sys
import time
import plotly.express as px
import demonstrator_dynamic_2_0
import os
#os.system("python demonstrator_dynamic_2_0.py")
df = pd.read_csv('C:/Users/AK125163/Desktop/zanosh1/masterfile_demo.csv', encoding= 'unicode_escape')
df_1 = pd.read_csv('C:/Users/AK125163/Desktop/zanosh1/masterfile_demo_part.csv', encoding= 'unicode_escape')

fig = px.histogram(df, x='Mean Values')


image_filename = 'plots/part_dynamic/demo_part_dynamic.png' # replace with your own image
encoded_image = base64.b64encode(open(image_filename, 'rb').read())

image_filename2 = 'plots/homline_part/demo_hom_line_part.png' # replace with your own image
encoded_image2 = base64.b64encode(open(image_filename2, 'rb').read())

image_filename3 = 'plots/cropped_tool_with_temp_mm/cropped_tool_with_temp_demo.png' # replace with your own image
encoded_image3 = base64.b64encode(open(image_filename3, 'rb').read())

image_filename4 = 'plots/histograms_with_distributions/histo_dist_demo.png' # replace with your own image
encoded_image4 = base64.b64encode(open(image_filename4, 'rb').read())


#app = Dash(__name__)

external_stylesheets = [
     dbc.themes.DARKLY,
    "static/css/style.css",
]

#avocado = pd.read_csv('masterfile_demo.csv')

#external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']


app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
colors = {
    'background': 'black',
    'text': 'black',              #7FDBFF
}

#app = Dash()

# Set up the app layout
# geo_dropdown = dcc.Dropdown(options=df['Mean Values'].unique(),
#                             value='Mean')

app.layout = html.Div(children=[
    html.H1(children='Process Automation for Consolidation Press'),
    # geo_dropdown,
    # dcc.Graph(id='price-graph')
])




tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
    'fontWeight': 'bold'
}

tab_selected_style = {
    'borderTop': '1px solid black',     #d6d6d6
    'borderBottom': '1px solid black',  #d6d6d6
    'backgroundColor': 'black',        #119DFF
    'color': 'white',
    'padding': '6px'
}

### Inputs ###
real_tool_size_x = 880
real_tool_size_y = 380
real_tool_crop_size = 20  # How many mm should be cropped from each side
real_part_size_x = 230
real_part_size_y = 150
threshold_limit = 10  # this value is substracted from the average T of the part which is used for thresholding
# Drawing constants
cross_size = 10  # was 20 for smaller pictures - if it should be back to constant values
ThreeD_graph = 0
old_crop = 1
below_temperature_delete = 100  # temperatures below this limit is not considered
w_crop_control = 0.5  # controls how many percentage of "0"s should be considered in the cropping process
h_crop_control = 0.6  # e.g: 400 rows, morethan 60% contains 0 -> delete
set_temperature = 200
percentage_for_ok_not_ok = 5

percentage_for_ok = 100 - percentage_for_ok_not_ok
threshold_limit_1 = threshold_limit + set_temperature
threshold_limit_2 = threshold_limit + set_temperature + 5
threshold_limit_3 = set_temperature - threshold_limit
threshold_limit_4 = set_temperature - threshold_limit - 5

# percentage_for_ok = 100 - percentage_for_ok_not_ok
# threshold_limit_1 = threshold_limit + set_temperature
# threshold_limit_2 = threshold_limit + set_temperature + 5
# threshold_limit_3 = set_temperature - threshold_limit
# threshold_limit_4 = set_temperature - threshold_limit - 5

# print('Mean temperature: ', mean_part)
# print('Standard deviation of the temperature: ', st_dev_part_1)
# print('Maximum temperature: ', max_T_part)
# print('Minimum temperature: ', min_T_part)
# print('Set temperature: ', set_temperature)
# print('Percentage for OK: ', percentage_for_ok)
# print('Threshold limit 1: ', threshold_limit_1)
# print('Threshold limit 2: ', threshold_limit_2)
# print('Threshold limit 3: ', threshold_limit_3)
# print('Threshold limit 4: ', threshold_limit_4)
# print('Name of file: ', filename)

app.layout = html.Div([
    html.H1(children='Process Automation for Consolidation Press', style={'textAlign': 'center',"color": "white" }),
    dcc.Tabs(id="tabs-styled-with-inline", value='tab-1', children=[
        dcc.Tab(label='Full Image', value='tab-1', style=tab_style, selected_style=tab_selected_style),
        dcc.Tab(label='Part Image', value='tab-2', style=tab_style, selected_style=tab_selected_style),
        dcc.Tab(label='Statistical Process Control', value='tab-3', style=tab_style, selected_style=tab_selected_style),
        dcc.Tab(label='Settings', value='tab-4', style=tab_style, selected_style=tab_selected_style),
    ], style=tabs_styles),
    html.Div(id='tabs-content-inline'),

])

@app.callback(Output('tabs-content-inline', 'children'),
              Input('tabs-styled-with-inline', 'value'))
def render_content(tab):
    if tab == 'tab-1':
        return html.Div([
            html.H3('Full image from IR camera'),
            html.Img(
                id='image4',
                src='data:image/png;base64,{}'.format(encoded_image2.decode()),
                height=280),

            html.Div(html.P([html.Br()])),

            html.Img(
                id='image1',
                src='data:image/png;base64,{}'.format(encoded_image2.decode()),
                height=280),

            html.Img(
                id='image3',
                src='data:image/png;base64,{}'.format(encoded_image3.decode()),
                height=280),
            dcc.Interval(
                id='interval-component',
                interval=1000,  # in milliseconds
                n_intervals=0
            )
        ])
    elif tab == 'tab-2':
        return html.Div([
        html.H3('Cropped image')]),


        # callbacks


    elif tab == 'tab-3':
        return html.Div([
            html.H3('Mean value and Standard deviation of temperature values')
        ])
    elif tab == 'tab-4':
        return html.Div([
            html.H3('Thresholding intervals '),
            html.H3("set temperature: 200"),
            html.H3()
        ])


import subprocess

#subprocess.call("demonstrator_dynamic_2_0.py", shell=True)


if __name__ == '__main__':
    app.run_server(debug=True)