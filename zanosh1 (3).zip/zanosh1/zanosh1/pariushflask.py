import flask
import io
import string
import time
import os
import numpy as np
import tensorflow as tf
from PIL import Image
from flask import Flask, jsonify, request

model = tf.keras.models.load_model('resnet50_food_model')


def prepare_image(img):
    img = Image.open(io.BytesIO(img))
    img = img.resize((224, 224))
    img = np.array(img)
    img = np.expand_dims(img, 0)
    return img


def predict_result(img):
    return 1 if model.predict(img)[0][0] > 0.5 else 0


app = Flask(__name__)


@app.route('/predict', methods=['POST'])
def infer_image():
    if 'file' not in request.files:
        return "Please try again. The Image doesn't exist"

    file = request.files.get('file')

    if not file:
        return

    img_bytes = file.read()
    img = prepare_image(img_bytes)

    return jsonify(prediction=predict_result(img))


@app.route('/', methods=['GET'])
def index():
    return 'Machine Learning Inference'


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')


       -------------------------
    from flask import Flask
    from dash import Dash
    import dash_core_components as dcc
    import dash_html_components as html

    server = Flask(__name__)
    app = dash.Dash(
        __name__,
        server=server,
        url_base_pathname='/dash'
    )

    app.layout = html.Div(id='dash-container') \
 \
                 @ server.route("/dash")


    def my_dash_app():
        return app.index()

    --------------------------------------------

    from flask import Flask, render_template
    import flask

    app = Flask(__name__)


    @app.route('/')
    def index():
        return render_template('index.html')


    if __name__ == '__main__':
        app.run(debug=True)

    ---------------------------------------------

    app = Flask(__name__)


    #
    @app.route("/", methods=["POST"])
    def index():
        ## TIG DATA
        input_nn = {}
        result_machine = {}

        data = request.get_json(force=True)
        jsonpath_expression = parse('observableList[*]')

        for match in jsonpath_expression.find(data):
            input_nn[match.value["name"]] = match.value["value"]

        result_nn, dic_inputs = get_result(input_nn)

        result_machine['header'] = data['header']
        result_machine['serialNumber'] = data['header'].get('device', {}).get('serialNumber')
        result_machine['productid'] = data.get('header', {}).get('productid')
        result_machine['timestamp'] = data.get('header', {}).get('timestamp')
        result_machine['shotCounter'] = input_nn['SZx']
        result_machine['torqueReal'] = input_nn['Mm']
        result_machine['plasticizingTimeReal'] = input_nn['ZDx']
        result_machine['T1'] = input_nn['Ist_Zylindertemperatur3']
        result_machine['T2'] = input_nn['Ist_Zylindertemperatur2']
        result_machine['T3'] = input_nn['Ist_Zylindertemperatur1']

        return Response(json.dumps({**result_machine, **dic_inputs, **result_nn}, indent=4),
                        mimetype='application/json')


    #
    if __name__ == "__main__":
        target_m = 35
        app.run(host="0.0.0.0", port=8080, debug=False)